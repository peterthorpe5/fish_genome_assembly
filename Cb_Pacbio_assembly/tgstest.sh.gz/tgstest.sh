#!/bin/bash -l
#SBATCH -J tgstest   #jobname
#SBATCH --partition=long
#SBATCH --cpus-per-task=3
#SBATCH --mem=8GB
#SBATCH --mail-type=ALL
#SBATCH --mail-user=pjt6@st-andrews.ac.uk


conda activate TGSgapcloser
cd /home/pthorpe/scratch/cb
#tgsgapcloser --tgstype pb --racon /mnt/shared/scratch/pthorpe/apps/conda/envs/TGSgapcloser/bin/racon \
#--scaff scaffolds_gapfilled_FINAL.fasta --reads /home/pthorpe/scratch/cb/raw_reads.fa --output tgs --thread 30
#
#tgsgapcloser --tgstype pb --racon /mnt/shared/scratch/pthorpe/apps/conda/envs/TGSgapcloser/bin/racon \
#--scaff tgs.scaff_seqs --reads /home/pthorpe/scratch/cb/raw_reads.fa --output tgs1 --thread 30
#
#tgsgapcloser --tgstype pb --racon /mnt/shared/scratch/pthorpe/apps/conda/envs/TGSgapcloser/bin/racon \
#--scaff tgs1.scaff_seqs --reads /home/pthorpe/scratch/cb/raw_reads.fa --output tgs2 --thread 30